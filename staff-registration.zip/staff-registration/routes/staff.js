const express = require('express');
const router = express.Router();
const Staff = require('../models/Staff');
const Department = require('../models/Department');
const { authenticate, requireAdmin } = require('../middleware/auth');

// @route   POST /api/staff
// @desc    Register a new staff member
// @access  Any logged-in user (user or admin)
router.post('/', authenticate, async (req, res) => {
  try {
    const { fullName, email, phone, dob, gender, department, designation, joiningDate, address } = req.body;

    if (!fullName || !email || !phone || !dob || !gender || !department || !designation || !joiningDate) {
      return res.status(400).json({ message: 'Please fill in all required fields.' });
    }

    const dept = await Department.findById(department).catch(() => null);
    if (!dept) {
      return res.status(400).json({ message: 'Please select a valid department.' });
    }

    const existing = await Staff.findOne({ email: email.toLowerCase().trim() });
    if (existing) {
      return res.status(409).json({ message: 'A staff member with this email is already registered.' });
    }

    const staff = new Staff({ fullName, email, phone, dob, gender, department, designation, joiningDate, address });
    const saved = await staff.save();
    await saved.populate('department', 'name code');
    res.status(201).json({ message: 'Staff registered successfully!', staff: saved });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ message: messages.join(', ') });
    }
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again later.' });
  }
});

// @route   GET /api/staff
// @desc    Get all staff (supports ?search= and ?department=)
// @access  Admin only
router.get('/', authenticate, requireAdmin, async (req, res) => {
  try {
    const { search, department } = req.query;
    let query = {};

    if (department) query.department = department;

    if (search) {
      query.$or = [
        { fullName: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { designation: { $regex: search, $options: 'i' } },
      ];
    }

    const staff = await Staff.find(query)
      .populate('department', 'name code')
      .sort({ createdAt: -1 });

    res.json(staff);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again later.' });
  }
});

// @route   GET /api/staff/:id
// @desc    Get single staff member by ID
// @access  Admin only
router.get('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const staff = await Staff.findById(req.params.id).populate('department', 'name code');
    if (!staff) return res.status(404).json({ message: 'Staff member not found.' });
    res.json(staff);
  } catch (err) {
    res.status(400).json({ message: 'Invalid staff ID.' });
  }
});

// @route   PUT /api/staff/:id
// @desc    Update a staff member
// @access  Admin only
router.put('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    if (req.body.department) {
      const dept = await Department.findById(req.body.department).catch(() => null);
      if (!dept) {
        return res.status(400).json({ message: 'Please select a valid department.' });
      }
    }

    const updated = await Staff.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    }).populate('department', 'name code');

    if (!updated) return res.status(404).json({ message: 'Staff member not found.' });
    res.json({ message: 'Staff updated successfully!', staff: updated });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ message: messages.join(', ') });
    }
    res.status(400).json({ message: 'Invalid request.' });
  }
});

// @route   DELETE /api/staff/:id
// @desc    Delete a staff member
// @access  Admin only
router.delete('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const deleted = await Staff.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: 'Staff member not found.' });
    res.json({ message: 'Staff deleted successfully!' });
  } catch (err) {
    res.status(400).json({ message: 'Invalid staff ID.' });
  }
});

module.exports = router;
