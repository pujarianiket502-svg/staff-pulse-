const express = require('express');
const router = express.Router();
const Department = require('../models/Department');
const Staff = require('../models/Staff');
const { authenticate, requireAdmin } = require('../middleware/auth');

// @route   POST /api/departments
// @desc    Create a new department
// @access  Admin only
router.post('/', authenticate, requireAdmin, async (req, res) => {
  try {
    const { name, code, description, headOfDepartment } = req.body;

    if (!name || !code) {
      return res.status(400).json({ message: 'Please provide a department name and code.' });
    }

    const existing = await Department.findOne({
      $or: [{ name: name.trim() }, { code: code.trim().toUpperCase() }],
    });
    if (existing) {
      return res.status(409).json({ message: 'A department with this name or code already exists.' });
    }

    const department = new Department({ name, code, description, headOfDepartment });
    const saved = await department.save();
    res.status(201).json({ message: 'Department created successfully!', department: saved });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ message: messages.join(', ') });
    }
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again later.' });
  }
});

// @route   GET /api/departments
// @desc    Get all departments, each with a live staff count
// @access  Any logged-in user (needed to populate the department dropdown)
router.get('/', authenticate, async (req, res) => {
  try {
    const { search } = req.query;
    let query = {};
    if (search) {
      query = {
        $or: [
          { name: { $regex: search, $options: 'i' } },
          { code: { $regex: search, $options: 'i' } },
        ],
      };
    }

    const departments = await Department.find(query).sort({ name: 1 }).lean();

    // Attach a live staff count to each department
    const counts = await Staff.aggregate([
      { $group: { _id: '$department', count: { $sum: 1 } } },
    ]);
    const countMap = {};
    counts.forEach((c) => {
      if (c._id) countMap[c._id.toString()] = c.count;
    });

    const withCounts = departments.map((d) => ({
      ...d,
      staffCount: countMap[d._id.toString()] || 0,
    }));

    res.json(withCounts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again later.' });
  }
});

// @route   GET /api/departments/:id
// @desc    Get a single department
// @access  Admin only
router.get('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const department = await Department.findById(req.params.id);
    if (!department) return res.status(404).json({ message: 'Department not found.' });
    res.json(department);
  } catch (err) {
    res.status(400).json({ message: 'Invalid department ID.' });
  }
});

// @route   PUT /api/departments/:id
// @desc    Update a department
// @access  Admin only
router.put('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const updated = await Department.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!updated) return res.status(404).json({ message: 'Department not found.' });
    res.json({ message: 'Department updated successfully!', department: updated });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ message: messages.join(', ') });
    }
    if (err.code === 11000) {
      return res.status(409).json({ message: 'A department with this name or code already exists.' });
    }
    res.status(400).json({ message: 'Invalid request.' });
  }
});

// @route   DELETE /api/departments/:id
// @desc    Delete a department (blocked if staff are still assigned to it)
// @access  Admin only
router.delete('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const staffCount = await Staff.countDocuments({ department: req.params.id });
    if (staffCount > 0) {
      return res.status(409).json({
        message: `Cannot delete: ${staffCount} staff member(s) are still assigned to this department. Reassign or remove them first.`,
      });
    }

    const deleted = await Department.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: 'Department not found.' });
    res.json({ message: 'Department deleted successfully!' });
  } catch (err) {
    res.status(400).json({ message: 'Invalid department ID.' });
  }
});

module.exports = router;
