const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();
const User = require('../models/User');
const { authenticate } = require('../middleware/auth');

function signToken(payload) {
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
}

// @route   POST /api/auth/signup
// @desc    Create a regular user account
router.post('/signup', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ message: 'Please provide a username, email, and password.' });
    }

    const existing = await User.findOne({
      $or: [{ email: email.toLowerCase().trim() }, { username: username.trim() }],
    });
    if (existing) {
      return res.status(409).json({ message: 'An account with this username or email already exists.' });
    }

    const user = new User({ username: username.trim(), email, password });
    await user.save();

    const token = signToken({ id: user._id, username: user.username, role: 'user' });
    res.status(201).json({
      message: 'Account created successfully!',
      token,
      user: { id: user._id, username: user.username, email: user.email, role: 'user' },
    });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ message: messages.join(', ') });
    }
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again later.' });
  }
});

// @route   POST /api/auth/login
// @desc    Log in as a regular user
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: 'Please provide your username/email and password.' });
    }

    const user = await User.findOne({
      $or: [{ username: username.trim() }, { email: username.trim().toLowerCase() }],
    }).select('+password');

    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ message: 'Invalid username or password.' });
    }

    const token = signToken({ id: user._id, username: user.username, role: 'user' });
    res.json({
      message: 'Logged in successfully!',
      token,
      user: { id: user._id, username: user.username, email: user.email, role: 'user' },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again later.' });
  }
});

// @route   POST /api/auth/admin-login
// @desc    Log in as the single fixed admin (credentials come from .env, not the DB)
router.post('/admin-login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: 'Please provide the admin username and password.' });
  }

  const validUsername = username === process.env.ADMIN_USERNAME;
  const validPassword = password === process.env.ADMIN_PASSWORD;

  if (!validUsername || !validPassword) {
    return res.status(401).json({ message: 'Invalid admin credentials.' });
  }

  const token = signToken({ id: 'admin', username, role: 'admin' });
  res.json({
    message: 'Logged in as admin!',
    token,
    user: { username, role: 'admin' },
  });
});

// @route   GET /api/auth/me
// @desc    Return the currently logged-in identity (used by the frontend to check session state)
router.get('/me', authenticate, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
