/* =====================================================================
   AUTH HELPERS — loaded on every page, before script.js
   Handles the logged-in session (JWT in localStorage), page guarding,
   and building the nav bar based on who is logged in.
===================================================================== */
const AUTH_API = '/api/auth';

function getToken() {
  return localStorage.getItem('token');
}

function getUser() {
  try {
    return JSON.parse(localStorage.getItem('authUser') || 'null');
  } catch {
    return null;
  }
}

function isLoggedIn() {
  return !!getToken();
}

function isAdmin() {
  const u = getUser();
  return !!u && u.role === 'admin';
}

function saveSession(token, user) {
  localStorage.setItem('token', token);
  localStorage.setItem('authUser', JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem('token');
  localStorage.removeItem('authUser');
}

function logout() {
  clearSession();
  window.location.href = 'login.html';
}

// Wrapper around fetch that attaches the Authorization header automatically.
// Also handles an expired/invalid session (401) by bouncing to login.
async function authFetch(url, options = {}) {
  const token = getToken();
  const headers = Object.assign({}, options.headers || {});
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(url, Object.assign({}, options, { headers }));

  if (res.status === 401) {
    clearSession();
    window.location.href = 'login.html';
    throw new Error('Session expired');
  }
  return res;
}

// Call at the top of any page that requires a logged-in user (any role).
function requireLogin() {
  if (!isLoggedIn()) {
    window.location.href = 'login.html';
    return false;
  }
  return true;
}

// Call at the top of any page that requires the admin role specifically.
function requireAdminRole() {
  if (!isLoggedIn()) {
    window.location.href = 'login.html';
    return false;
  }
  if (!isAdmin()) {
    window.location.href = 'index.html';
    return false;
  }
  return true;
}

// Builds the right-hand side of the navbar based on session state.
function renderNavAuthLinks() {
  const nav = document.querySelector('.nav-links');
  // The login/signup pages ship an intentionally empty .nav-links (just branding) —
  // skip building a session link there.
  if (!nav || nav.children.length === 0) return;

  const user = getUser();

  // Toggle visibility of admin-only nav links that are already in the HTML
  nav.querySelectorAll('[data-admin-only]').forEach((el) => {
    el.style.display = user && user.role === 'admin' ? '' : 'none';
  });
  nav.querySelectorAll('[data-user-only]').forEach((el) => {
    el.style.display = user ? '' : 'none';
  });

  // Append a session indicator + logout / login link
  const existing = nav.querySelector('.nav-session');
  if (existing) existing.remove();

  const sessionEl = document.createElement(user ? 'a' : 'a');
  sessionEl.className = 'nav-session';
  if (user) {
    sessionEl.href = '#';
    sessionEl.textContent = `Logout (${user.username}${user.role === 'admin' ? ' · admin' : ''})`;
    sessionEl.addEventListener('click', (e) => {
      e.preventDefault();
      logout();
    });
  } else {
    sessionEl.href = 'login.html';
    sessionEl.textContent = 'Login';
  }
  nav.appendChild(sessionEl);
}

document.addEventListener('DOMContentLoaded', renderNavAuthLinks);
