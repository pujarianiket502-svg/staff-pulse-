const STAFF_API = '/api/staff';
const DEPT_API = '/api/departments';

// ---------- Shared utilities ----------
function showAlert(message, type = 'success') {
  const alertBox = document.getElementById('alertBox');
  if (!alertBox) return;
  alertBox.textContent = message;
  alertBox.className = `alert ${type}`;
  alertBox.style.display = 'block';
  window.scrollTo({ top: 0, behavior: 'smooth' });
  setTimeout(() => {
    alertBox.style.display = 'none';
  }, 4000);
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return str
    .toString()
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function formatDate(dateStr) {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

// Deterministic color tag (1-6) for a department name, so the same
// department always renders with the same badge color across pages.
function tagClassFor(name) {
  if (!name) return 'tag-1';
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) % 6;
  }
  return `tag-${Math.abs(hash) + 1}`;
}

async function fetchDepartments() {
  const res = await authFetch(DEPT_API);
  if (!res.ok) throw new Error('Failed to load departments');
  return res.json();
}

// Populate a <select> with department options. Returns the list fetched.
async function populateDepartmentSelect(selectEl, selectedId = '') {
  try {
    const departments = await fetchDepartments();
    if (!departments.length) {
      selectEl.innerHTML = '<option value="">No departments yet — add one first</option>';
      return departments;
    }
    selectEl.innerHTML =
      '<option value="">Select department</option>' +
      departments
        .map(
          (d) =>
            `<option value="${d._id}" ${d._id === selectedId ? 'selected' : ''}>${escapeHtml(d.name)} (${escapeHtml(d.code)})</option>`
        )
        .join('');
    return departments;
  } catch (err) {
    console.error(err);
    selectEl.innerHTML = '<option value="">Could not load departments</option>';
    return [];
  }
}

/* =====================================================================
   REGISTRATION FORM (index.html)
===================================================================== */
const staffForm = document.getElementById('staffForm');
if (staffForm && requireLogin()) {
  const departmentSelect = document.getElementById('department');
  populateDepartmentSelect(departmentSelect);

  staffForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = {
      fullName: document.getElementById('fullName').value.trim(),
      email: document.getElementById('email').value.trim(),
      phone: document.getElementById('phone').value.trim(),
      dob: document.getElementById('dob').value,
      gender: document.getElementById('gender').value,
      department: departmentSelect.value,
      designation: document.getElementById('designation').value.trim(),
      joiningDate: document.getElementById('joiningDate').value,
      address: document.getElementById('address').value.trim(),
    };

    if (!formData.department) {
      showAlert('Please select a department.', 'error');
      return;
    }

    try {
      const res = await authFetch(STAFF_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (!res.ok) {
        showAlert(data.message || 'Something went wrong.', 'error');
        return;
      }

      showAlert('✅ Staff registered successfully!', 'success');
      staffForm.reset();
      populateDepartmentSelect(departmentSelect);
    } catch (err) {
      console.error(err);
      showAlert('Could not connect to server. Please try again.', 'error');
    }
  });
}

/* =====================================================================
   STAFF LIST (staff.html)
===================================================================== */
const staffBody = document.getElementById('staffBody');
const searchInput = document.getElementById('searchInput');

if (staffBody && requireAdminRole()) {
  let debounceTimer;

  async function loadStaff(search = '') {
    try {
      const url = search ? `${STAFF_API}?search=${encodeURIComponent(search)}` : STAFF_API;
      const res = await authFetch(url);
      const staff = await res.json();
      renderStaff(staff);
    } catch (err) {
      console.error(err);
      showAlert('Failed to load staff. Is the server running?', 'error');
    }
  }

  function renderStaff(staffList) {
    const emptyState = document.getElementById('emptyState');
    staffBody.innerHTML = '';

    if (!staffList.length) {
      emptyState.style.display = 'block';
      return;
    }
    emptyState.style.display = 'none';

    staffList.forEach((s, index) => {
      const deptName = s.department ? s.department.name : 'Unassigned';
      const row = document.createElement('tr');
      row.innerHTML = `
        <td class="cell-muted">${index + 1}</td>
        <td class="cell-name">${escapeHtml(s.fullName)}</td>
        <td class="cell-muted">${escapeHtml(s.email)}</td>
        <td class="cell-muted">${escapeHtml(s.phone)}</td>
        <td><span class="badge ${tagClassFor(deptName)}">${escapeHtml(deptName)}</span></td>
        <td>${escapeHtml(s.designation)}</td>
        <td class="cell-muted">${formatDate(s.joiningDate)}</td>
        <td class="cell-muted">${escapeHtml(s.gender)}</td>
        <td>
          <button class="action-btn" title="Edit" onclick="openEdit('${s._id}')">✏️</button>
          <button class="action-btn" title="Delete" onclick="deleteStaff('${s._id}')">🗑️</button>
        </td>
      `;
      staffBody.appendChild(row);
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        loadStaff(searchInput.value.trim());
      }, 300);
    });
  }

  window.deleteStaff = async (id) => {
    if (!confirm('Are you sure you want to delete this staff member?')) return;
    try {
      const res = await authFetch(`${STAFF_API}/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) {
        showAlert(data.message || 'Failed to delete staff member.', 'error');
        return;
      }
      showAlert('🗑️ Staff deleted successfully.', 'success');
      loadStaff(searchInput ? searchInput.value.trim() : '');
    } catch (err) {
      console.error(err);
      showAlert('Could not connect to server.', 'error');
    }
  };

  // Edit modal
  const editModal = document.getElementById('editModal');
  const editForm = document.getElementById('editForm');
  const cancelEdit = document.getElementById('cancelEdit');
  const editDepartmentSelect = document.getElementById('editDepartment');

  window.openEdit = async (id) => {
    try {
      const res = await authFetch(`${STAFF_API}/${id}`);
      const s = await res.json();
      if (!res.ok) {
        showAlert(s.message || 'Failed to load staff member.', 'error');
        return;
      }
      document.getElementById('editId').value = s._id;
      document.getElementById('editFullName').value = s.fullName;
      document.getElementById('editEmail').value = s.email;
      document.getElementById('editPhone').value = s.phone;
      document.getElementById('editDesignation').value = s.designation;
      await populateDepartmentSelect(editDepartmentSelect, s.department ? s.department._id : '');
      editModal.style.display = 'flex';
    } catch (err) {
      console.error(err);
      showAlert('Could not connect to server.', 'error');
    }
  };

  if (cancelEdit) {
    cancelEdit.addEventListener('click', () => {
      editModal.style.display = 'none';
    });
  }

  if (editForm) {
    editForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('editId').value;
      const updated = {
        fullName: document.getElementById('editFullName').value.trim(),
        email: document.getElementById('editEmail').value.trim(),
        phone: document.getElementById('editPhone').value.trim(),
        department: editDepartmentSelect.value,
        designation: document.getElementById('editDesignation').value.trim(),
      };

      try {
        const res = await authFetch(`${STAFF_API}/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updated),
        });
        const data = await res.json();
        if (!res.ok) {
          showAlert(data.message || 'Failed to update staff member.', 'error');
          return;
        }
        editModal.style.display = 'none';
        showAlert('✅ Staff updated successfully!', 'success');
        loadStaff(searchInput ? searchInput.value.trim() : '');
      } catch (err) {
        console.error(err);
        showAlert('Could not connect to server.', 'error');
      }
    });
  }

  loadStaff();
}

/* =====================================================================
   DEPARTMENTS MANAGEMENT (departments.html)
===================================================================== */
const deptGrid = document.getElementById('deptGrid');

if (deptGrid && requireAdminRole()) {
  let debounceTimer;
  const deptSearchInput = document.getElementById('searchInput');
  const statStrip = document.getElementById('statStrip');
  const deptModal = document.getElementById('deptModal');
  const deptForm = document.getElementById('deptForm');
  const deptModalTitle = document.getElementById('deptModalTitle');
  const openAddDept = document.getElementById('openAddDept');
  const cancelDeptModal = document.getElementById('cancelDeptModal');

  async function loadDepartments(search = '') {
    try {
      const url = search ? `${DEPT_API}?search=${encodeURIComponent(search)}` : DEPT_API;
      const res = await authFetch(url);
      const departments = await res.json();
      renderStats(departments);
      renderDeptGrid(departments);
    } catch (err) {
      console.error(err);
      showAlert('Failed to load departments. Is the server running?', 'error');
    }
  }

  function renderStats(departments) {
    const totalStaff = departments.reduce((sum, d) => sum + (d.staffCount || 0), 0);
    const largest = departments.reduce(
      (max, d) => ((d.staffCount || 0) > (max.staffCount || 0) ? d : max),
      { staffCount: 0, name: '—' }
    );

    statStrip.innerHTML = `
      <div class="stat-box">
        <div class="stat-value">${departments.length}</div>
        <div class="stat-label">Departments</div>
      </div>
      <div class="stat-box">
        <div class="stat-value">${totalStaff}</div>
        <div class="stat-label">Total staff assigned</div>
      </div>
      <div class="stat-box">
        <div class="stat-value">${escapeHtml(largest.name || '—')}</div>
        <div class="stat-label">Largest department</div>
      </div>
    `;
  }

  function renderDeptGrid(departments) {
    const emptyState = document.getElementById('emptyState');
    deptGrid.innerHTML = '';

    if (!departments.length) {
      emptyState.style.display = 'block';
      return;
    }
    emptyState.style.display = 'none';

    departments.forEach((d) => {
      const card = document.createElement('div');
      card.className = 'dept-card';
      card.innerHTML = `
        <div class="dept-card-top">
          <div>
            <h3>${escapeHtml(d.name)}</h3>
            <div class="dept-code">${escapeHtml(d.code)}</div>
          </div>
          <span class="badge ${tagClassFor(d.name)}">${d.staffCount || 0} staff</span>
        </div>
        <div class="dept-desc">${d.headOfDepartment ? '👤 ' + escapeHtml(d.headOfDepartment) : '<em>No head of department set</em>'}${d.description ? '<br>' + escapeHtml(d.description) : ''}</div>
        <div class="dept-meta">
          <span class="cell-muted">Created ${formatDate(d.createdAt)}</span>
          <div class="dept-actions">
            <button class="action-btn" title="Edit" onclick="openEditDept('${d._id}')">✏️</button>
            <button class="action-btn" title="Delete" onclick="deleteDept('${d._id}')">🗑️</button>
          </div>
        </div>
      `;
      deptGrid.appendChild(card);
    });
  }

  if (deptSearchInput) {
    deptSearchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        loadDepartments(deptSearchInput.value.trim());
      }, 300);
    });
  }

  function openAddModal() {
    deptModalTitle.textContent = 'Add Department';
    deptForm.reset();
    document.getElementById('deptId').value = '';
    deptModal.style.display = 'flex';
  }

  if (openAddDept) openAddDept.addEventListener('click', openAddModal);
  if (cancelDeptModal) cancelDeptModal.addEventListener('click', () => (deptModal.style.display = 'none'));

  window.openEditDept = async (id) => {
    try {
      const res = await authFetch(`${DEPT_API}/${id}`);
      const d = await res.json();
      if (!res.ok) {
        showAlert(d.message || 'Failed to load department.', 'error');
        return;
      }
      deptModalTitle.textContent = 'Edit Department';
      document.getElementById('deptId').value = d._id;
      document.getElementById('deptName').value = d.name;
      document.getElementById('deptCode').value = d.code;
      document.getElementById('deptHead').value = d.headOfDepartment || '';
      document.getElementById('deptDescription').value = d.description || '';
      deptModal.style.display = 'flex';
    } catch (err) {
      console.error(err);
      showAlert('Could not connect to server.', 'error');
    }
  };

  window.deleteDept = async (id) => {
    if (!confirm('Delete this department? This only works if no staff are currently assigned to it.')) return;
    try {
      const res = await authFetch(`${DEPT_API}/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) {
        showAlert(data.message || 'Failed to delete department.', 'error');
        return;
      }
      showAlert('🗑️ Department deleted successfully.', 'success');
      loadDepartments(deptSearchInput ? deptSearchInput.value.trim() : '');
    } catch (err) {
      console.error(err);
      showAlert('Could not connect to server.', 'error');
    }
  };

  if (deptForm) {
    deptForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('deptId').value;
      const payload = {
        name: document.getElementById('deptName').value.trim(),
        code: document.getElementById('deptCode').value.trim(),
        headOfDepartment: document.getElementById('deptHead').value.trim(),
        description: document.getElementById('deptDescription').value.trim(),
      };

      try {
        const res = await authFetch(id ? `${DEPT_API}/${id}` : DEPT_API, {
          method: id ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!res.ok) {
          showAlert(data.message || 'Failed to save department.', 'error');
          return;
        }
        deptModal.style.display = 'none';
        showAlert(id ? '✅ Department updated successfully!' : '✅ Department created successfully!', 'success');
        loadDepartments(deptSearchInput ? deptSearchInput.value.trim() : '');
      } catch (err) {
        console.error(err);
        showAlert('Could not connect to server.', 'error');
      }
    });
  }

  loadDepartments();
}
